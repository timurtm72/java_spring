package main

type adidasShirt struct {
	shirt
}

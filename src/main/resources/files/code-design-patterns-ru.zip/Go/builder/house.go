package main

type house struct {
	windowType string
	doorType   string
	floor      int
}

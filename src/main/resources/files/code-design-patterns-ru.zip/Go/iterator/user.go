package main

type user struct {
	name string
	age  int
}
